import React, { useState, useEffect  } from 'react';
import bike from '../images/bike1.jpg';
import car from '../images/car1.jpg';
import watch from '../images/watch1.jpg';
import './products.css'






const Home =()=>{

    // creating image card
    const [masterList, setMList] = useState( [
        {name:"Bike",img:bike, price:500, id:1},
        {name:"Car",img:car, price:1000, id:2},
        {name:"Watch",img:watch, price:20, id:3}
    ])

    const [list, setList ]= useState(JSON.parse(JSON.stringify(masterList)))

    const [money, setMoney] = useState(["INR", "USD"]);


//taking care of selected money type  
const [selectedCurr, setSelectedCurr]=useState("INR");
const [rate, setrate]=useState();

const CurrSelected =(e)=>{
    setSelectedCurr(e.target.value);
}

const changeMoney=()=>{
  if(selectedCurr === 'INR'){
    console.log('called money chage inr')
    console.log(masterList)
    setList(masterList);
  }
  else if(selectedCurr === 'USD'){
      console.log('called money chage usd')
      var temp =[]
      var temp2 = JSON.parse(JSON.stringify(masterList))
      temp2.forEach(obj=>{
          obj.price = obj.price*rate;
          temp.push(obj);
      })
      setList(temp);
  }
}

// making API call to fetch current money value
    function callAPI(){
        if(selectedCurr === 'USD'){
        var url = 'https://api.exchangeratesapi.io/latest?base=INR';        
        fetch(url).then((response) => response.json())
        .then(function(data) { setrate(data.rates.USD); console.log(data.rates.USD)})
        .catch((error) => console.log(error));
    }
    else{
        setrate()
    }
    }

    useEffect(() => {
        callAPI()
      });
    useEffect(()=>{
        changeMoney();
    },[rate])  
    


//creating dropdown
    const dropDown =
    <div>
    <select onChange={CurrSelected}>
        {money.map(item=><option value={item}>{item}</option>)}      
     </select>     
    </div>   



    const html = list.map(item=>
    <div class="card">
    <img src={item.img} alt="Avatar" class="maintainWidth"/>
    <div key={item.id}>
      <h4><b>{item.name}</b></h4> 
    <p>{selectedCurr+' '+item.price}</p> 
    </div>
    </div>
    )


    
    return(
        <div>
            <div class="topnav">
            <a class="active" >{dropDown}</a>
             
        </div>
            
            <div class ='flex'>{html}</div>   
        </div>        
    )
}

export default Home;