﻿using emailLogger.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace emailLogger.Utility
{
    public class appUtil
    {
        public static void  updateResponseObject(ref apiResponse apiResponse, string status, object responseData) {
            apiResponse.responseStatus = status;
            apiResponse.responseData = responseData;
        }
    }
}