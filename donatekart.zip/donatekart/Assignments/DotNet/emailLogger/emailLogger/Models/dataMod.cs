﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace emailLogger.Models
{
    public class data
    {
        public string name { get; set; }
        public string email { get; set; }
        public string phoneNumber { get; set; }
        public string fromEMail { get; set; }
        public string subject { get; set; }
        public string body { get; set; }
    }

    public class inputDonor {
        public string name { get; set; }
        public string email { get; set; }
        public string phoneNumber { get; set; }
    }

    public class inputEmail {
        public string toEMail { get; set; }
        public string fromEMail { get; set; }
        public string subject { get; set; }
        public string body { get; set; }

    }
    public interface _actionsDonor {
        void writeDonorDetailsToFile(inputDonor inp);
    }

    public interface _actionsDonorEmail
    {
        void writeDonorEmailToFile(inputEmail inpu);
    }

    public class apiResponse {
        public string responseStatus { get; set; }
        public object responseData { get; set; }
    }


    
}