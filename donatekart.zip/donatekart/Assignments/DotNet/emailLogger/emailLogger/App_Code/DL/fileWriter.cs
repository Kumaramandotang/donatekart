﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace emailLogger.App_Code.DL
{
    public class fileWriter
    {
        public void writeStringToFile(string text, string fileName) {
            File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + @"\outPut\" + fileName + ".txt", text);
            
        }
    }
}