﻿using emailLogger.App_Code.DL;
using emailLogger.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace emailLogger.App_Code.BL
{
    public class allActionImp : _actionsDonor, _actionsDonorEmail
    {
        fileWriter dl = new fileWriter();
        public void writeDonorDetailsToFile(inputDonor inp)
        {
            string text = "Donor Name: "+inp.name+"\nDonor Email: "+inp.email+"\nDonor Phone Number: "+inp.phoneNumber;
            dl.writeStringToFile(text, "donorDetails");
            
        }
        public void writeDonorEmailToFile(inputEmail inp)
        {
            string text = "From: " + inp.fromEMail + "\n\nTo Email: " + inp.toEMail + "\n\nSubject: " + inp.subject+"\n\nBody: \n\t"
                +inp.body;
            dl.writeStringToFile(text, "donorEmail");
        }
    }
}