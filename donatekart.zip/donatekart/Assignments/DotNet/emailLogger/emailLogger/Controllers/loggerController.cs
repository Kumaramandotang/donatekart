﻿using emailLogger.Models;
using System.Web.Http;
using emailLogger.App_Code.BL;
using System;
using emailLogger.Utility;
using System.Configuration;

namespace emailLogger.Controllers
{
    public class loggerController : ApiController
    {

        allActionImp bl = new allActionImp();

        [HttpPost]
        [Route("api/logger/logger")]
        public apiResponse logger([FromBody]data input) {
            
            inputDonor inp1 = new inputDonor();
            inputEmail inp2 = new inputEmail();
            apiResponse apiResponse = new apiResponse();
            inp1.email = input.email;
            inp1.name = input.name;
            inp1.phoneNumber = input.phoneNumber;
            inp2.toEMail = input.email;
            inp2.fromEMail = input.fromEMail;
            inp2.subject = input.subject;
            inp2.body = input.body;
            try
            {
                bl.writeDonorDetailsToFile(inp1);
                bl.writeDonorEmailToFile(inp2);
                appUtil.updateResponseObject(ref apiResponse, ConfigurationManager.AppSettings["Success.Ret.Code"].ToString(), string.Empty);
            }
            catch (Exception ex)
            {

                throw ex;
            }           
            
            return apiResponse;          
        }

       

    }
}
